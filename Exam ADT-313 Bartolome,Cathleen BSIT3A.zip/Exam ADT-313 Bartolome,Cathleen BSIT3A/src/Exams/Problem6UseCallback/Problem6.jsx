import { useCallback, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [selected, setSelected] = useState({
    vin: '',
    make: '',
    model: '',
    year: '',
    color: ''
  });

  const handleEdit = useCallback((car) => {
    setSelected(car);
  }, []);

  const handleDelete = useCallback((vin) => {
    setCars((prevCars) => prevCars.filter((car) => car.vin !== vin));
  }, []);

  const handleSave = useCallback(() => {
    setCars((prevCars) => [...prevCars, selected]);
    setSelected({ vin: '', make: '', model: '', year: '', color: '' });
  }, [selected]);

  const handleUpdate = useCallback(() => {
    setCars((prevCars) =>
      prevCars.map((car) => (car.vin === selected.vin ? selected : car))
    );
    setSelected({ vin: '', make: '', model: '', year: '', color: '' });
  }, [selected]);

  const handleClear = useCallback(() => {
    setSelected({ vin: '', make: '', model: '', year: '', color: '' });
  }, []);

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN:{' '}
          <input
            type='text'
            value={selected.vin}
            onChange={(e) => setSelected({ ...selected, vin: e.target.value })}
          />
        </div>
        <div style={{ display: 'block' }}>
          Make:{' '}
          <input
            type='text'
            value={selected.make}
            onChange={(e) => setSelected({ ...selected, make: e.target.value })}
          />
        </div>
        <div style={{ display: 'block' }}>
          Model:{' '}
          <input
            type='text'
            value={selected.model}
            onChange={(e) => setSelected({ ...selected, model: e.target.value })}
          />
        </div>
        <div style={{ display: 'block' }}>
          Year:{' '}
          <input
            type='text'
            value={selected.year}
            onChange={(e) => setSelected({ ...selected, year: e.target.value })}
          />
        </div>
        <div style={{ display: 'block' }}>
          Color:{' '}
          <input
            type='text'
            value={selected.color}
            onChange={(e) => setSelected({ ...selected, color: e.target.value })}
          />
        </div>
        <button type='button' onClick={handleSave}>Save</button>
        <button type='button' onClick={handleUpdate}>Update</button>
        <button type='button' onClick={handleClear}>Clear</button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car) => (
              <tr key={car.vin}>
                <td>{car.vin}</td>
                <td>{car.make}</td>
                <td>{car.model}</td>
                <td>{car.year}</td>
                <td>{car.color}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(car)}>Edit</button>
                  <button type='button' onClick={() => handleDelete(car.vin)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
