import { useContext } from 'react';
import { DataContext } from '../Problem7';

export default function SelectedValue() {
  const { selectedData } = useContext(DataContext);

  return (
    <div>
      <h3>Selected Value</h3>
      <pre>{JSON.stringify(selectedData, null, 2)}</pre>
    </div>
  );
}
