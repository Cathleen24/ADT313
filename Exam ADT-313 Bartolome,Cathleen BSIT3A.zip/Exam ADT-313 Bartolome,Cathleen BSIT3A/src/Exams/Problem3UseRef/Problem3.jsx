import { useRef } from 'react';

function Problem3() {
  const inputRefs = useRef([]);

  const focusInput = (index) => {
    inputRefs.current[index].focus();
  };

  return (
    <>
      {Array.from({ length: 10 }, (_, index) => (
        <div key={index} style={{ display: 'block' }}>
          Input {index + 1}: <input type='text' ref={(el) => (inputRefs.current[index] = el)} />
        </div>
      ))}
      <button type='button' onClick={() => focusInput(0)}>Focus First Input</button>
    </>
  );
}

export default Problem3;
