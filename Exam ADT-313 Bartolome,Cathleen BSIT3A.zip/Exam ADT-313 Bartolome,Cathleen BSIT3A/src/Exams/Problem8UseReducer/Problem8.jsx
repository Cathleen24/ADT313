import { useReducer, useState } from 'react';
import data from './problem8mock_data.json';

const initialState = {
  foods: data,
  selected: {
    food_name: '',
    price: '',
    expiration_date: '',
    calories: ''
  }
};

function reducer(state, action) {
  switch (action.type) {
    case 'CREATE':
      return {
        ...state,
        foods: [...state.foods, action.payload],
        selected: initialState.selected
      };
    case 'READ':
      return {
        ...state,
        selected: action.payload
      };
    case 'UPDATE':
      return {
        ...state,
        foods: state.foods.map((food) =>
          food.food_name === state.selected.food_name ? state.selected : food
        ),
        selected: initialState.selected
      };
    case 'DELETE':
      return {
        ...state,
        foods: state.foods.filter((food) => food.food_name !== action.payload)
      };
    case 'CLEAR':
      return {
        ...state,
        selected: initialState.selected
      };
    default:
      return state;
  }
}

export default function Problem8() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { foods, selected } = state;

  const handleChange = (e) => {
    const { name, value } = e.target;
    dispatch({
      type: 'READ',
      payload: { ...selected, [name]: value }
    });
  };

  const handleSave = () => {
    dispatch({ type: 'CREATE', payload: selected });
  };

  const handleUpdate = () => {
    dispatch({ type: 'UPDATE' });
  };

  const handleDelete = (food_name) => {
    dispatch({ type: 'DELETE', payload: food_name });
  };

  const handleClear = () => {
    dispatch({ type: 'CLEAR' });
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            type='text'
            name='food_name'
            value={selected.food_name}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            type='text'
            name='price'
            value={selected.price}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            type='text'
            name='expiration_date'
            value={selected.expiration_date}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            type='text'
            name='calories'
            value={selected.calories}
            onChange={handleChange}
          />
        </div>

        <button type='button' onClick={handleSave}>Save</button>
        <button type='button' onClick={handleUpdate}>Update</button>
        <button type='button' onClick={handleClear}>Clear</button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((food, index) => (
              <tr key={index}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type='button' onClick={() => dispatch({ type: 'READ', payload: food })}>Edit</button>
                  <button type='button' onClick={() => handleDelete(food.food_name)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
